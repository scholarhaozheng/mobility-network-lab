# Third-party notices

## UrbanNav reference-position figure

The selected Hong Kong 12-point projection figure uses PolyU IPNL
UrbanNav-HK-Medium-Urban-1 SPAN-CPT+IE ground-truth/reference positions.
The provider's [UrbanNav resource page](https://www.polyu.edu.hk/aae/ipn-lab/us/en/resources/urbannav-dataset/)
labels the dataset MIT, and its [repository](https://github.com/IPNL-POLYU/UrbanNavDataset/blob/master/README.md#urbannav-hk-medium-urban-1)
links the exact ground-truth file. The [asset-specific publication record](docs/assets/hong_kong/visual_release_r1/PUBLICATION_SCOPE.txt)
documents the narrow interpretation and attribution. Original provider files,
full point tables and other point-level derivatives are not included.

## Open Mobility Data Visibility

This project includes five selected original OMDV implementations and two
controlled example fixtures with the explicit permission of their copyright
holder, Hao Zheng, under the root MIT License. The exact selected-file scope is
recorded in
[catalog/omdv-authorized-files.json](catalog/omdv-authorized-files.json).

The source OMDV repository retains its own all-rights-reserved placeholder.
This selected-copy permission does not relicense that complete repository.
Raw data tables, archives, caches, manuscripts, endpoint lists, and unselected
figures are not copied here. Aggregate factual values retain commit and SHA-256
provenance in
[catalog/omdv-provenance.json](catalog/omdv-provenance.json).

## Scope of the root license

The root [MIT License](LICENSE) applies only to original project code for which the copyright holder has the right to grant that license. It does not relicense third-party code, third-party data, external tools or upstream projects. Any third-party material added in the future must retain its own copyright, license and attribution notices.

No source code from the external projects listed below is copied in this
upload. They are referenced for interoperability, data vocabulary, or optional
upstream preparation only.

## Runtime dependencies not vendored

| Dependency | Use | Distribution status |
|---|---|---|
| [NumPy](https://numpy.org/) | Numerical arrays | Installed separately; no package source or binary is included |
| [SciPy](https://scipy.org/) | Linear programming and sparse algorithms | Installed separately; no package source or binary is included |
| [PyYAML](https://pyyaml.org/) | Configuration parsing | Installed separately; no package source or binary is included |
| [pandas](https://pandas.pydata.org/) | Authorized OMDV catalog normalization, summaries, and city matching | Installed separately in the data-tools environment; no package source or binary is included |
| [markdown-it-py](https://github.com/executablebooks/markdown-it-py) | Documentation generation | Installed separately; no package source or binary is included |

Each dependency remains governed by the terms supplied by its own maintainers and distributors.

## Referenced upstream projects not bundled

| Project | Relationship to Mobility Computation Lab |
|---|---|
| [GMNS](https://github.com/zephyr-data-specs/GMNS) | Referenced network vocabulary and specification; no GMNS repository source is copied here |
| [GMNS Plus Dataset](https://github.com/HanZhengIntelliTransport/GMNS_Plus_Dataset) | Provider of network derivatives; the selected frozen Sioux finite-time inputs retain its Apache-2.0 notice and upstream TNTP attribution. No provider archive is copied. See [data scope](DATA_LICENSES.md). |
| [TAPLab](https://github.com/asu-trans-ai-lab/TAPLab) | Referenced external assignment and validation ecosystem; no TAPLab source or benchmark data is copied here |
| [tap-b](https://github.com/spartalab/tap-b) | Official Algorithm B mathematical solver referenced at commit `040135a20c771fbb84766df6a97cff981fa5df4b`; MIT upstream source/binary is not copied here |
| [OSM2GMNS](https://github.com/asu-trans-ai-lab/OSM2GMNS) | Referenced optional upstream preparation tool; no OSM2GMNS source is copied here |
| [grid2demand](https://github.com/asu-trans-ai-lab/grid2demand) | Referenced optional upstream demand tool; no grid2demand source is copied here |
| [TransportationNetworks](https://github.com/bstabler/TransportationNetworks) | Referenced benchmark collection; no raw TransportationNetworks dataset is copied here |

Follow the license and attribution terms published by the exact upstream version you obtain. A link or compatibility statement in this repository is not a license grant for an upstream project.

The selected [Algorithm B task-local adapter, contract and evaluator](algorithms/origin_based_algorithm_b/README.md) are original MIT candidate code. The Sioux official TAPLab adapter audit used TAPLab commit `081e44a0dd451c549d6903933516bccb4166bbd0`. Boston's accepted numerical runs used the task-local lossless adapter, not TAPLab's stock converter. The upstream TAPLab/tap-b MIT notices are retained at their linked sources; this repository does not vendor those trees.

The [ADMM R2_S public-safe source and authored fixtures](algorithms/admm_r2/README.md) are project material. Boston derived figures and the 125-row ADMM/LP comparison table use previously public GMNS Plus `21_Boston` geometry and identifiers, source commit `116447ab641cca1ed34797d019c8e704063393c3`, under Apache-2.0 attribution. The root MIT license does not relicense the underlying GMNS Plus dataset. The four frozen Sioux finite-time input CSVs are included under the [2026-10-04 data scope](DATA_LICENSES.md); unrelated city dynamic inputs and saved solver states remain excluded.

## Retained project source

The selected numerical engine, public input workflow, verification modules and static Frank–Wolfe source are recorded in [`catalog/source-files.json`](catalog/source-files.json). Their hashes are checked by `tools/check_repository.py`. The maintainer confirmed the right to publish the original project code under the root MIT License on 2026-09-17.

Selected OMDV copies and their MCL integration glue are separately allowlisted
in
[`catalog/omdv-authorized-files.json`](catalog/omdv-authorized-files.json);
their destination hashes are checked by the publication gate.
